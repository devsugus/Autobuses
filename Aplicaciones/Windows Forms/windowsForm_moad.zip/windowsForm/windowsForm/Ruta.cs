﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace windowsForm
{
    class Ruta
    {
        public int Id { get; set; }
        public int Origen { get; set; }
        public int Destino { get; set; }
        //public int Km { get; set; }
        public System.TimeSpan Tiempo { get; set; }
        //public int Precio { get; set; }

        //public virtual Ciudades Ciudades { get; set; }
        //public virtual Ciudades Ciudades1 { get; set; }
    }
}
