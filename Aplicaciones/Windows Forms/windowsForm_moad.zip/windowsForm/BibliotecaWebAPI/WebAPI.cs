﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;

namespace BibliotecaWebAPI
{
    public class WebAPI : IWebAPIcs
    {
        public List<CiudadesAPI> DameCiudades()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@"https://webapiseseautobuses.azurewebsites.net/api/CiudadesAPI");
            using (HttpWebResponse respuesta = (HttpWebResponse)request.GetResponse())
            using (Stream stream = respuesta.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                var json_ = reader.ReadToEnd();
                return JsonConvert.DeserializeObject<List<CiudadesAPI>>(json_);
            }
        }

        public List<RutasAPI> DameRutas(string ciudadOrigen, string ciudadDestino)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(@"https://webapiseseautobuses.azurewebsites.net/api/RutasAPI/" +
                ciudadOrigen + "/" + ciudadDestino);
            using (HttpWebResponse respuesta = (HttpWebResponse)request.GetResponse())
            using (Stream stream = respuesta.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                var json_ = reader.ReadToEnd();
                return JsonConvert.DeserializeObject<List<RutasAPI>>(json_);
            }
        }

        //APIRepositori modelo;
        //public WebAPI()
        //{
        //    this.modelo = new APIRepositori();
        //}

        //[HttpGet]
        //[Route("api/RutasAPI/{Origen}/{Destino}")]

        //public List<RutasAPI> GetRutaOrigen(int Origen, int Destino)
        //{
        //    return modelo.GetRutasporOrigenyDestino(Origen, Destino);
        //}
    }
}
