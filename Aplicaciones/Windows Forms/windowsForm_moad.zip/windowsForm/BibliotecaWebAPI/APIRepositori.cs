﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaWebAPI
{
    class APIRepositori
    {


    //    AutobusesSeseEntities entidad;
    //    public RepositorioRutas()
    //    {
    //        this.entidad = new AutobusesSeseEntities();
    //    }
    //    public List<RutasAPI> GetRutasporOrigenyDestino(int origen, int destino)
    //    {

    //        var consulta2 = from Rutas in entidad.Rutas
    //                        where Rutas.Origen == origen &&
    //                              Rutas.Destino == destino
    //                        select Rutas;




    //        if (consulta2.Count() == 0)
    //        {
    //            return null;
    //        }
    //        else
    //        {
    //            return consulta2.ToList();
    //        }

    //    }
    //}

}
}
