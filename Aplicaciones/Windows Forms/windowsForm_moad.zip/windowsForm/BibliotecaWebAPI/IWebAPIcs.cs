﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BibliotecaWebAPI
{
    public interface IWebAPIcs
    {
        List<RutasAPI> DameRutas(string ciudadOrigen, string ciudadDestino);
        List<CiudadesAPI> DameCiudades();

        

}
}
